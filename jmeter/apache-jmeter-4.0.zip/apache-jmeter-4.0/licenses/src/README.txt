This directory contains additional licenses for software contained in source distributions
